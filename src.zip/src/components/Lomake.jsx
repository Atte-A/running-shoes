import { useState } from 'react'

function Lomake() {
  const [kenka, setKenka] = useState({ merkki:'', malli: '', hinta: '', kilometrit: ''})
  const [viesti, setViesti] = useState('')

  const muuta = (e) => {
    setViesti('')
    setKenka({...kenka, [e.target.name]: e.target.value})
  }

  const lisaa = () => {
    setKenka({ merkki:'', malli: '', hinta: '', kilometrit: ''})

    if (kenka.merkki.length > 0 && kenka.malli.length > 0) {
      setViesti('Kenkä lisättiin')
    } else {
      setViesti('Lisää kengälle merkki sekä malli')
    }
  }

  return (
    <form>
      <div>
        <label>Merkki </label>
        <input type='text' name='merkki' value={kenka.merkki} onChange={muuta} />
      </div>
      <div>
        <label>Malli </label>
        <input type='text' name='malli' value={kenka.malli} onChange={muuta} />
      </div>
      <div>
        <label>Hinta </label>
        <input type='text' name='hinta' value={kenka.hinta} onChange={muuta} />
        <div>
          <label>Kilometrit </label>
        <input type='text' name='kilometrit' value={kenka.kilometrit} onChange={muuta} />
        </div>
      </div>
      <div>
        <input type='button' value='Lisää kenkä' onClick={lisaa} />
      </div>
      <div>
        {viesti}
      </div>
    </form>
  )

}

export default Lomake