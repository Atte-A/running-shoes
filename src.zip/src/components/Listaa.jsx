function Listaa({ lista }){
  return (
    <>
      {
        lista.map(kenka => {
          return (
            <div key={kenka.merkki}>
              Merkki: {kenka.merkki} <br />
              Malli: {kenka.malli} <br />
              Hinta: {kenka.hinta} euroa <br />
              Kilometrit: {kenka.kilometrit} kilometriä <br />
              <br />
            </div>
          )
        })
      }
    </>
  )
}

export default Listaa