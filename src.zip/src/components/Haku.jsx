import { useState } from 'react'

function Haku({ lista }) {
  const [merkki, setMerkki] = useState('')

  const muuta = (e) => {
    setMerkki(e.target.value)
  }

  const haeKengat = () => {
    if (merkki.length === 0) {
      return null
    }
    const result = lista.filter(kenka => kenka.merkki.toLowerCase().includes(merkki.toLowerCase()) || kenka.malli.toLowerCase().includes(merkki.toLowerCase()))

      if (result.length > 0) {
        let haku = result.map(kenka => {
          return (
            <div key={kenka.merkki + kenka.malli}>
              <br/>
              Merkki: {kenka.merkki} <br/>
              Malli: {kenka.malli} <br/>
              Hinta: {kenka.hinta} euroa <br/>
              Kilometrit: {kenka.kilometrit} kilometriä <br/>
            </div>
          )
        })
        return (haku)
      } else {
        return (
          <div>
            Kyseisellä haulla ei löytynyt kenkiä.
          </div>
        )
      }
    }
  
  return (
    <div>
      <form>
        <label>Hae </label>
        <input type='text' name='merkki' placeholder='merkillä tai mallilla' value={merkki} onChange={muuta} /><br/>
      </form>
      {haeKengat()}
    </div>
  )
}

export default Haku