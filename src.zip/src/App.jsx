import Lomake from './components/Lomake'
import Listaa from './components/Listaa'
import Haku from './components/Haku'

  let kengat = [
    {
      merkki: 'Saucony',
      malli: 'Endorphin Speed 4',
      hinta: '210',
      kilometrit: '0'
    },
    {
      merkki: 'Hoka',
      malli: 'Clifton 10',
      hinta: '160',
      kilometrit: '72'
    },
    {
      merkki: 'Hoka',
      malli: 'Clifton 9',
      hinta: '149',
      kilometrit: '520'
    },
    {
      merkki: 'Adidas',
      malli: 'Evo 4',
      hinta: '229',
      kilometrit: '35'
    }
  ]

function App() {
  return (
    <div>
      <h2>RunningShoes</h2>
      <Lomake />
      <br/>
      <Haku lista={kengat} />
      <h4>Kengät</h4>
      <Listaa lista={kengat} />
    </div>
  )
}

export default App