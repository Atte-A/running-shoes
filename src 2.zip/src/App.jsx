import { BrowserRouter, Routes, Route } from 'react-router'
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Container, Box, Typography } from '@mui/material'
import Lomake from './components/Lomake'
import Listaa from './components/Listaa'
import Haku from './components/Haku'
import { useState } from 'react'
import { grey, lime } from '@mui/material/colors';
import DrawerMUI from './components/DrawerMUI';

const theme = createTheme({
  palette: {
    primary: {main: lime[500], contrastText: grey[800]},
    text: {primary: grey[900], secondary: grey[800]}
  }
})

function App() {

  const [kengat, setKengat] = useState([])

  const lisaaKenka = (uusi) => {
    setKengat([...kengat, uusi])
  }

  return (
    <BrowserRouter>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box>
          {<DrawerMUI/>}
          <Box>
            <Container maxWidth='sm' sx={{ mt: 4 }}>
              <Routes>
                <Route path='/' element={<Lomake lisaaKenka={lisaaKenka}/>}></Route>
                <Route path='/listaus' element={<Listaa lista={kengat}/>}></Route>
                <Route path='/haku' element={<Haku lista={kengat}/>}></Route>
                <Route path='*' element={<Lomake lisaaKenka={lisaaKenka}/>}></Route>
              </Routes>
            </Container>
          </Box>
        </Box>
      </ThemeProvider>
    </BrowserRouter>
  )
}

export default App

// TODO: Listaa kengät Card -komponentteina ja geneerinen lenkkarin kuva jokaiseen
// lisää mahdollisuus muokata ja poistaa kenkä
// lisää reitti visuaaliseen analytiikkaan - kenkien tähtiarvostelut, hintaluokat, tms.
// JOS aikaa --> kirjautuminen käyttäjätunnuksella ja salasanalla