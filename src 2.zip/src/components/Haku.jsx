import { Box, Typography, TextField, Rating } from '@mui/material'
import { lime } from '@mui/material/colors'
import { useState } from 'react'

function Haku({ lista }) {
  const [merkki, setMerkki] = useState('')

  const muuta = (e) => {
    setMerkki(e.target.value)
  }

  const haeKengat = () => {
    if (merkki.length === 0) {
      return null
    }
    const result = lista.filter(kenka => kenka.merkki.toLowerCase().includes(merkki.toLowerCase()) || kenka.malli.toLowerCase().includes(merkki.toLowerCase()))

      if (result.length > 0) {
        let haku = result.map(kenka => {
          return (
            <Box sx={{ mb: 2 }} key={kenka.id}>
              <Typography>Merkki: {kenka.merkki}</Typography>
              <Typography>Malli: {kenka.malli}</Typography>
              <Typography>Hinta: {kenka.hinta}</Typography>
              <Typography>Kommentit: {kenka.kommentit}</Typography>
              <Typography>Arvostelu:
                <Rating 
                name='arvostelu'
                value={kenka.arvostelu}
                readOnly
                sx={{ color: lime[500] }}
                />
              </Typography>
            </Box>
          )
        })
        return (haku)
      } else {
        return (
          <Typography>
            Kyseisellä haulla ei löytynyt kenkiä.
          </Typography>
        )
      }
    }
  
  return (
    <Box>
      <Typography variant='h4' sx={{ mb: 1.5 }}>RunningShoes</Typography>
      <Typography variant='h6'sx={{ mb: 4 }}>Hae tiettyä kenkää</Typography>
      <TextField sx={{ mb: 4 }}
      label='Hae'
      variant='outlined'
      placeholder='merkillä tai mallilla'
      value={merkki}
      onChange={muuta}
      fullWidth
      />
      {haeKengat()}
    </Box>
  )
}

export default Haku