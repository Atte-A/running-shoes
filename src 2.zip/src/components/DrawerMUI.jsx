import { useState } from 'react'
import { Link } from 'react-router';
import { IconButton, Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText } from '@mui/material'
import MenuIcon from '@mui/icons-material/Menu';
import ListAltIcon from '@mui/icons-material/ListAlt';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';

function DrawerMUI() {
  const [open, setOpen] = useState(false)

  const handleOpen = () => { setOpen(true) }
  const handleClose = () => { setOpen(false) }

  return (
    <>
      <IconButton onClick={handleOpen}><MenuIcon sx={{ mr: 1}}/></IconButton>
      <Drawer open={open} onClick={handleClose} >
        <List>
          <ListItem>
            <ListItemButton component={Link} to='/'>
              <ListItemIcon><AddIcon/></ListItemIcon>
              <ListItemText primary='Lisää kenkä' />
            </ListItemButton>
          </ListItem>
          <ListItem>
            <ListItemButton component={Link} to='/listaus'>
              <ListItemIcon><ListAltIcon/></ListItemIcon>
              <ListItemText primary='Näytä kaikki' />
            </ListItemButton>
          </ListItem>
          <ListItem>
            <ListItemButton component={Link} to='/haku'>
              <ListItemIcon><SearchIcon/></ListItemIcon>
              <ListItemText primary='Haku' />
            </ListItemButton>
          </ListItem>
        </List>
      </Drawer>
    </>
  )
}

export default DrawerMUI