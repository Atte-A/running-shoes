import { Box, Rating, Typography } from '@mui/material'
import { lime } from '@mui/material/colors'

function Listaa({ lista }){
  return (
    <Box>
      <Typography variant='h4' sx={{ mb: 1.5 }}>RunningShoes</Typography>
      <Typography variant='h6' sx={{ mb: 4 }}>Kaikki kengät</Typography>
      {
        lista.map(kenka => {
          return (
            <Box key={kenka.id} sx={{ mb: 4 }}>
              <Typography>Merkki: {kenka.merkki}</Typography>
              <Typography>Malli: {kenka.malli}</Typography>
              <Typography>Hinta: {kenka.hinta} euroa</Typography>
              <Typography>Kommentit: {kenka.kommentit}</Typography>
              <Typography>Arvostelu:
                <Rating 
                name='arvostelu'
                value={kenka.arvostelu}
                readOnly
                sx={{ color: lime[500] }}
                />
              </Typography>
            </Box>
          )
        })
      }
    </Box>
  )
}

export default Listaa