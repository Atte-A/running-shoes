import { useState } from 'react'
import { Box, TextField, Button, Typography, Rating } from '@mui/material'
import { lime } from '@mui/material/colors'

function Lomake({lisaaKenka}) {
  const [kenka, setKenka] = useState({ id: '', merkki:'', malli: '', hinta: '', kommentit: '', arvostelu: 0})
  const [viesti, setViesti] = useState('')

  const muuta = (e) => {
    setViesti('')
    setKenka({...kenka, [e.target.name]: e.target.value})
  }

  const muutaArvostelu = (e, uusiArvo) => {
    setKenka({...kenka, arvostelu: uusiArvo})
  }

  const lisaa = () => {
    if (!kenka.merkki || !kenka.malli) {
      setViesti('Lisää kengälle merkki sekä malli')
      return
    }

    lisaaKenka({
      ...kenka,
      id: Date.now()
    })

    setViesti('Kenkä lisättiin')

    setKenka({
      merkki: '',
      malli: '',
      hinta: '',
      kommentit: '',
      arvostelu: 0
    })
  }


  return (
    <Box component='form' sx={{ display:'flex', flexDirection: 'column', gap: 2 }}>
      <Typography variant='h4' sx={{ mb: 1.5 }}>RunningShoes</Typography>
      <Typography variant='h6'>Lisää kenkä</Typography>
      <TextField
      label='Merkki'
      name='merkki'
      value={kenka.merkki}
      onChange={muuta}
      />
      <TextField
      label='Malli'
      name='malli'
      value={kenka.malli}
      onChange={muuta}
      />
      <TextField
      label='Hinta'
      name='hinta'
      value={kenka.hinta}
      onChange={muuta}
      />
            <TextField
      label='Kommentit'
      name='kommentit'
      value={kenka.kommentit}
      onChange={muuta}
      />
      <Box sx={{ display:'flex', gap: 1 }}>
        <Typography>Arvostelu:</Typography>
        <Rating name='arvostelu' value={kenka.arvostelu} onChange={muutaArvostelu} sx={{ color: lime[500]}} />
      </Box>
      <Button variant='contained' onClick={lisaa}>Lisää kenkä</Button>
      {viesti && <Typography>{viesti}</Typography>}
    </Box>
  )

}

export default Lomake